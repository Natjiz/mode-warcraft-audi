@echo off
chcp 65001 >nul
cd /d "%~dp0"
set PYTHONUTF8=1
"%~dp0runtime\python.exe" -m companion
if errorlevel 1 pause
