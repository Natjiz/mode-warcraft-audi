local ok, reason = WarcraftAudi:RegisterPack("Akunda_ruRU", {
    { questID = 50913, locale = "ruRU", stage = "detail", gender = "male", files = { "Interface\\AddOns\\WarcraftAudi_Akunda_ruRU\\Audio\\ruRU\\50913\\detail_male.ogg" } },
    { questID = 50913, locale = "ruRU", stage = "detail", gender = "female", files = { "Interface\\AddOns\\WarcraftAudi_Akunda_ruRU\\Audio\\ruRU\\50913\\detail_female.ogg" } },
    { questID = 50913, locale = "ruRU", stage = "progress", files = { "Interface\\AddOns\\WarcraftAudi_Akunda_ruRU\\Audio\\ruRU\\50913\\progress.ogg" } },
    { questID = 50913, locale = "ruRU", stage = "complete", files = { "Interface\\AddOns\\WarcraftAudi_Akunda_ruRU\\Audio\\ruRU\\50913\\complete.ogg" } },
})
if not ok then WarcraftAudi:Notify("Voice pack rejected: " .. tostring(reason)) end
